from PIL import Image
import numpy as np
import math

def process(iname):
    
    area = 0
    perimeter = 0
    gradient = 0
    rowlist = []
    collist = []
    centerRow = 0
    centerCol = 0
    distance = []
    deviation = 0

    input = Image.open(iname).convert('L')
    arr = np.array(input)
    
    for x in range(arr.shape[0]):
        for y in range(arr.shape[1]):
            if arr[x][y] < 220:
                area += 1
                gradient += arr[x][y]
                rowlist.append(x)
                collist.append(y)
                # Check surrounding area for perimeter
                if (x >= 1 and x < arr.shape[0]-1 and y >= 1 and y < arr.shape[1]-1):
                    if (arr[x+1][y] >= 220 or arr[x-1][y] >= 220 or arr[x][y+1] >= 220 or arr[x][y-1] >= 220):
                        perimeter += 1
    
    ##Gets center of mass
    centerRow = np.mean(rowlist)
    centerCol = np.mean(collist)

	#Finds distance to center of mass
    for x in range(len(rowlist)):
        distance.append(math.sqrt((centerRow - rowlist[x])**2 + (centerCol - collist[x])**2))
    
    ##standard dev
    deviation = np.std(distance)
    gradient = gradient / area
    circularity = 4 * math.pi * area / (perimeter**2)

    print("\nImage height (rows):", arr.shape[0])
    print("\nImage width (columns):", arr.shape[1])
    print("\nArea (dark pixels):", area)
    print("\nPerimeter:", perimeter)
    print("\nAverage gradient:", gradient)
    print("\nCircularity:", circularity)
    print("\nDeviation of distances:", deviation)

for x in range(10):
	print("\nTRIAL ERASER", x+1)
	name = "eraser_"+str(x+1)+".jpg"
	process(name)
for x in range(10):
	print("\nTRIAL PENCIL", x+1)
	name = "pencil_"+str(x+1)+".jpg"
	process(name)
for x in range(10):
	print("\nTRIAL SCISSORS", x+1)
	name = "sci_"+str(x+1)+".jpg"
	process(name)
