from PIL import Image
import numpy as np

input = Image.open('erase.jpeg').convert('L')
arr = np.array(input)

area = 0
perimeter = 0
gradient = 0
#we need to do this as numpy arrays are diffeent from normal arrays
for x in range(arr.shape[0]):
	for y in range(arr.shape[1]):
		if arr[x][y] < 220:
			area += 1
			gradient += arr[x][y]
			if (x>=1 and x<arr.shape[0]-1 and y>=1 and y<arr.shape[1]-1) and (arr[x+1][y]>240 or arr[x-1][y]>240 or arr[x][y+1]>240 or arr[x][y-1]>240):
				perimeter += 1
gradient = gradient / area
print(arr)
print("\n")
print(arr.shape[0])
print("\n")
print(arr.shape[1])
print("\n")
print(area)
print("\n")
print(perimeter)
print("\n")
print(gradient)
